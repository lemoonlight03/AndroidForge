@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.gamal.weeklyplanner

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg=Color(0xFF0B1220); private val Panel=Color(0xFF121D2E); private val Panel2=Color(0xFF19283D); private val Line=Color(0xFF293A52); private val MainText=Color(0xFFE8EEF7); private val Muted=Color(0xFF93A4BA); private val Green=Color(0xFF42D392); private val Blue=Color(0xFF69A9FF)
private val days=listOf("Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu")
private val cats=listOf("Tidur","Kuliah/Pekerjaan","Belajar","Olahraga","Makan & Pribadi","Ibadah","Sosial/Organisasi","Hiburan","Fleksibel","Lainnya")
data class Act(val id:Long,val title:String,val cat:String,val day:Int,val start:String,val end:String,val done:Boolean)
data class Workout(val id:Long,val title:String,val day:Int,val mins:Int,val detail:String,val done:Boolean)
data class Habit(val id:Long,val title:String,val checked:Boolean)

class LocalDb(c:Context):SQLiteOpenHelper(c,"gamal_planner.db",null,1){
 override fun onCreate(db:SQLiteDatabase){
  db.execSQL("CREATE TABLE acts(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,cat TEXT,day INTEGER,start TEXT,end TEXT,done INTEGER DEFAULT 0)")
  db.execSQL("CREATE TABLE workouts(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,day INTEGER,mins INTEGER,detail TEXT,done INTEGER DEFAULT 0)")
  db.execSQL("CREATE TABLE habits(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT)")
  db.execSQL("CREATE TABLE checks(habit_id INTEGER,day_key TEXT,checked INTEGER,PRIMARY KEY(habit_id,day_key))")
  listOf("Tidur 7–9 jam","Minum air teratur","Belajar mandiri","Makan teratur","Ibadah tepat waktu","Evaluasi hari ini").forEach{val v=ContentValues().apply{put("title",it)};db.insert("habits",null,v)}
  listOf(arrayOf("Kalistenik — Lower Body","0","35","Squat, reverse lunge, calf raises, glute bridge"),arrayOf("Jalan cepat / jogging","1","30","Intensitas nyaman"),arrayOf("Upper Body & Core","3","30","Incline push-up, plank, bird dog"),arrayOf("Simulasi hiking","5","45","Jalan menanjak, carrier ringan jika nyaman")).forEach{a->val v=ContentValues().apply{put("title",a[0]);put("day",a[1].toInt());put("mins",a[2].toInt());put("detail",a[3])};db.insert("workouts",null,v)}
 }
 override fun onUpgrade(db:SQLiteDatabase,o:Int,n:Int){}
 fun acts(day:Int):List<Act>{val r=mutableListOf<Act>();readableDatabase.rawQuery("SELECT * FROM acts WHERE day=? ORDER BY start",arrayOf(day.toString())).use{c->while(c.moveToNext())r.add(Act(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(4),c.getString(5),c.getInt(6)==1))};return r}
 fun allActs()=(0..6).flatMap{acts(it)}
 fun addAct(t:String,c:String,d:Int,s:String,e:String){val v=ContentValues().apply{put("title",t);put("cat",c);put("day",d);put("start",s);put("end",e)};writableDatabase.insert("acts",null,v)}
 fun toggleAct(id:Long,b:Boolean){writableDatabase.execSQL("UPDATE acts SET done=? WHERE id=?",arrayOf(if(b)1 else 0,id))}
 fun deleteAct(id:Long){writableDatabase.delete("acts","id=?",arrayOf(id.toString()))}
 fun workouts():List<Workout>{val r=mutableListOf<Workout>();readableDatabase.rawQuery("SELECT * FROM workouts ORDER BY day",null).use{c->while(c.moveToNext())r.add(Workout(c.getLong(0),c.getString(1),c.getInt(2),c.getInt(3),c.getString(4),c.getInt(5)==1))};return r}
 fun addWorkout(t:String,d:Int,m:Int,x:String){val v=ContentValues().apply{put("title",t);put("day",d);put("mins",m);put("detail",x)};writableDatabase.insert("workouts",null,v)}
 fun toggleWorkout(id:Long,b:Boolean){writableDatabase.execSQL("UPDATE workouts SET done=? WHERE id=?",arrayOf(if(b)1 else 0,id))}
 fun habits():List<Habit>{val key=dayKey();val r=mutableListOf<Habit>();readableDatabase.rawQuery("SELECT h.id,h.title,COALESCE(c.checked,0) FROM habits h LEFT JOIN checks c ON h.id=c.habit_id AND c.day_key=?",arrayOf(key)).use{c->while(c.moveToNext())r.add(Habit(c.getLong(0),c.getString(1),c.getInt(2)==1))};return r}
 fun toggleHabit(id:Long,b:Boolean){val v=ContentValues().apply{put("habit_id",id);put("day_key",dayKey());put("checked",if(b)1 else 0)};writableDatabase.insertWithOnConflict("checks",null,v,SQLiteDatabase.CONFLICT_REPLACE)}
 fun addHabit(t:String){val v=ContentValues().apply{put("title",t)};writableDatabase.insert("habits",null,v)}
 private fun dayKey()=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).format(java.util.Date())
}
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);val db=LocalDb(this);setContent{App(db)}}}

@Composable fun App(db:LocalDb){var tab by remember{mutableIntStateOf(0)};var day by remember{mutableIntStateOf((java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK)+5)%7)};var tick by remember{mutableIntStateOf(0)};var addAct by remember{mutableStateOf(false)};var addWorkout by remember{mutableStateOf(false)};var addHabit by remember{mutableStateOf(false)}
 val acts=remember(tick){db.allActs()};val workouts=remember(tick){db.workouts()};val habits=remember(tick){db.habits()};val total=acts.sumOf{duration(it.start,it.end)};val totals=cats.associateWith{c->acts.filter{it.cat==c}.sumOf{duration(it.start,it.end)}}
 MaterialTheme(colorScheme=darkColorScheme(primary=Green,background=Bg,surface=Panel,onSurface=MainText,onBackground=MainText)){
 Scaffold(containerColor=Bg,bottomBar={NavigationBar(containerColor=Panel){val names=listOf("Home","Jadwal","Workout","Habit","Analisis");val icons=listOf(Icons.Default.Home,Icons.Default.CalendarMonth,Icons.Default.FitnessCenter,Icons.Default.CheckCircle,Icons.Default.BarChart);names.forEachIndexed{i,n->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(icons[i],n)},label={Text(n,fontSize=10.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Green,selectedTextColor=Green,indicatorColor=Panel2,unselectedIconColor=Muted,unselectedTextColor=Muted))}}}){pad->Column(Modifier.fillMaxSize().padding(pad).background(Bg)){
 Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(40.dp).background(Green,RoundedCornerShape(13.dp)),contentAlignment=Alignment.Center){Text("G",color=Bg,fontWeight=FontWeight.Black,fontSize=22.sp)};Spacer(Modifier.width(10.dp));Column{Text("Gamal Weekly Planner",fontWeight=FontWeight.Bold,fontSize=18.sp);Text("Plan your time. Build your life.",fontSize=11.sp,color=Muted)}}
 when(tab){0->Home(acts,workouts,habits,total,{tab=1},{tab=2});1->Schedule(day,{day=it},acts.filter{it.day==day},db,{tick++},{addAct=true});2->WorkoutPage(workouts,db,{tick++},{addWorkout=true});3->HabitPage(habits,db,{tick++},{addHabit=true});else->Analytics(acts,total,totals)}
 }}
 if(addAct)ActDialog({addAct=false}){t,c,d,s,e->db.addAct(t,c,d,s,e);addAct=false;tick++}
 if(addWorkout)WorkoutDialog({addWorkout=false}){t,d,m,x->db.addWorkout(t,d,m,x);addWorkout=false;tick++}
 if(addHabit)HabitDialog({addHabit=false}){t->db.addHabit(t);addHabit=false;tick++}
 }}
}
@Composable fun Base(content:@Composable ColumnScope.()->Unit){Column(Modifier.fillMaxSize().padding(horizontal=15.dp),content=content)}
@Composable fun Card(content:@Composable ColumnScope.()->Unit){Column(Modifier.fillMaxWidth().background(Panel,RoundedCornerShape(17.dp)).padding(15.dp),content=content)}
@Composable fun Heading(t:String,s:String){Column(Modifier.padding(bottom=12.dp)){Text(t,fontSize=20.sp,fontWeight=FontWeight.Bold);Text(s,fontSize=12.sp,color=Muted)}}
@Composable fun Stat(v:String,l:String,mod:Modifier=Modifier){Card{Text(v,fontSize=25.sp,fontWeight=FontWeight.Bold,color=Green);Text(l,fontSize=11.sp,color=Muted)}}
@Composable fun Home(acts:List<Act>,workouts:List<Workout>,habits:List<Habit>,total:Double,goSchedule:()->Unit,goWorkout:()->Unit){val today=(java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK)+5)%7;Base{Heading("Ringkasan mingguan","Kelola 168 jam dengan lebih sadar.");Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("%.1f".format(total),"Jam terjadwal",Modifier.weight(1f));Stat("%.1f".format((168-total).coerceAtLeast(0.0)),"Jam tersisa",Modifier.weight(1f))};Spacer(Modifier.height(8.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("${acts.count{it.done}}","Aktivitas selesai",Modifier.weight(1f));Stat("${if(habits.isEmpty())0 else habits.count{it.checked}*100/habits.size}%","Habit hari ini",Modifier.weight(1f))};Spacer(Modifier.height(12.dp));Card{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("Agenda hari ini",fontWeight=FontWeight.Bold);TextButton(onClick=goSchedule){Text("Lihat",color=Green)}};val list=acts.filter{it.day==today}.sortedBy{it.start};if(list.isEmpty())Text("Belum ada agenda hari ini.",color=Muted,fontSize=12.sp) else list.forEach{Text("${it.start}  ${it.title}",fontWeight=FontWeight.SemiBold,fontSize=13.sp);Text(it.cat,color=Muted,fontSize=10.sp)}};Spacer(Modifier.height(12.dp));Card{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Latihan minggu ini",fontWeight=FontWeight.Bold);TextButton(onClick=goWorkout){Text("Lihat",color=Green)}};workouts.take(4).forEach{Text("${days[it.day]} · ${it.title}",fontSize=13.sp);Text("${it.mins} menit · ${it.detail}",fontSize=11.sp,color=Muted);Spacer(Modifier.height(7.dp))}}}}
@Composable fun Schedule(day:Int,setDay:(Int)->Unit,items:List<Act>,db:LocalDb,refresh:()->Unit,add:()->Unit){Base{Heading("Jadwal 168 Jam","Pilih hari dan atur aktivitasmu.");Row(horizontalArrangement=Arrangement.spacedBy(2.dp)){days.forEachIndexed{i,d->TextButton(onClick={setDay(i)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(0.dp)){Text(d.take(3),fontSize=10.sp,color=if(day==i)Green else Muted)}}};Card{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text(days[day],fontWeight=FontWeight.Bold);Text("%.1f jam terjadwal".format(items.sumOf{duration(it.start,it.end)}),fontSize=11.sp,color=Muted)};Button(onClick=add,colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Icon(Icons.Default.Add,null);Text("Tambah")}};Spacer(Modifier.height(8.dp));if(items.isEmpty())Text("Belum ada aktivitas. Tekan Tambah untuk membuat jadwal.",color=Muted,fontSize=12.sp) else items.sortedBy{it.start}.forEach{a->Text("${a.start}–${a.end}  ${a.title}",fontWeight=FontWeight.SemiBold,fontSize=13.sp);Text(a.cat,fontSize=10.sp,color=Muted);Row(verticalAlignment=Alignment.CenterVertically){Checkbox(a.done,{db.toggleAct(a.id,it);refresh()},colors=CheckboxDefaults.colors(checkedColor=Green));Text("Selesai",fontSize=11.sp,color=Muted);Spacer(Modifier.weight(1f));IconButton(onClick={db.deleteAct(a.id);refresh()}){Icon(Icons.Default.Delete,null,tint=Color(0xFFFF7E88))}};Divider(color=Line)}};Text("Cegah jadwal bertumpuk dan sisakan waktu pemulihan.",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=10.dp))}}
@Composable fun WorkoutPage(items:List<Workout>,db:LocalDb,refresh:()->Unit,add:()->Unit){Base{Heading("Workout Tracker","Target awal: empat sesi per minggu.");Card{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("${items.count{it.done}} / ${items.size}",fontSize=25.sp,color=Green,fontWeight=FontWeight.Bold);Text("Sesi selesai",fontSize=11.sp,color=Muted)};Button(onClick=add,colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Icon(Icons.Default.Add,null);Text("Tambah")}}};Spacer(Modifier.height(10.dp));items.forEach{w->Card{Text("${days[w.day]} · ${w.title}",fontWeight=FontWeight.Bold);Text("${w.mins} menit",color=Green,fontSize=12.sp);Text(w.detail,color=Muted,fontSize=11.sp);Row(verticalAlignment=Alignment.CenterVertically){Checkbox(w.done,{db.toggleWorkout(w.id,it);refresh()},colors=CheckboxDefaults.colors(checkedColor=Green));Text("Tandai selesai",fontSize=11.sp,color=Muted)}};Spacer(Modifier.height(8.dp))}}}
@Composable fun HabitPage(items:List<Habit>,db:LocalDb,refresh:()->Unit,add:()->Unit){Base{Heading("Habit Tracker","Bangun rutinitas kecil setiap hari.");Card{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("${items.count{it.checked}} / ${items.size}",fontSize=25.sp,color=Green,fontWeight=FontWeight.Bold);Text("Habit selesai hari ini",fontSize=11.sp,color=Muted)};Button(onClick=add,colors=ButtonDefaults.buttonColors(containerColor=Green,contentColor=Bg)){Icon(Icons.Default.Add,null);Text("Tambah")}}};Spacer(Modifier.height(10.dp));items.forEach{h->Card{Row(verticalAlignment=Alignment.CenterVertically){Checkbox(h.checked,{db.toggleHabit(h.id,it);refresh()},colors=CheckboxDefaults.colors(checkedColor=Green));Text(h.title,fontSize=13.sp,fontWeight=FontWeight.SemiBold)}};Spacer(Modifier.height(7.dp))}}}
@Composable fun Analytics(acts:List<Act>,total:Double,totals:Map<String,Double>){Base{Heading("Analisis Waktu","Distribusi aktivitas dari total 168 jam.");Card{Text("%.1f / 168 jam".format(total),fontSize=26.sp,color=Green,fontWeight=FontWeight.Bold);LinearProgressIndicator(progress={(total/168).coerceIn(0.0,1.0).toFloat()},modifier=Modifier.fillMaxWidth().padding(vertical=9.dp),color=Green,trackColor=Line);Text("%.0f%% waktu terjadwal".format(total/168*100),fontSize=11.sp,color=Muted)};Spacer(Modifier.height(10.dp));Card{Text("Jam per kategori",fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));totals.filter{it.value>0}.toList().sortedByDescending{it.second}.forEach{(name,value)->Row(Modifier.fillMaxWidth().padding(vertical=5.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(name,fontSize=12.sp);Text("%.1f jam".format(value),fontSize=12.sp,color=Green)}};if(total==0.0)Text("Tambahkan aktivitas untuk melihat analisis.",color=Muted,fontSize=12.sp)};Spacer(Modifier.height(10.dp));Card{Text("Jumlah aktivitas: ${acts.size}",fontSize=12.sp,color=Muted);Text("Selesai: ${acts.count{it.done}}",fontSize=12.sp,color=Muted);Text("Belum dialokasikan: %.1f jam".format((168-total).coerceAtLeast(0.0)),fontSize=12.sp,color=Muted)}}}
@Composable fun ActDialog(close:()->Unit,save:(String,String,Int,String,String)->Unit){var title by remember{mutableStateOf("")};var cat by remember{mutableStateOf("Belajar")};var day by remember{mutableIntStateOf(0)};var start by remember{mutableStateOf("08:00")};var end by remember{mutableStateOf("09:00")};AlertDialog(onDismissRequest=close,containerColor=Panel,title={Text("Tambah aktivitas")},text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(title,{title=it},label={Text("Nama aktivitas")});var ce by remember{mutableStateOf(false)};ExposedDropdownMenuBox(expanded=ce,onExpandedChange={ce=it}){OutlinedTextField(cat,{},Modifier.menuAnchor().fillMaxWidth(),readOnly=true,label={Text("Kategori")});ExposedDropdownMenu(ce,{ce=false}){cats.forEach{DropdownMenuItem(text={Text(it)},onClick={cat=it;ce=false})}}};var de by remember{mutableStateOf(false)};ExposedDropdownMenuBox(expanded=de,onExpandedChange={de=it}){OutlinedTextField(days[day],{},Modifier.menuAnchor().fillMaxWidth(),readOnly=true,label={Text("Hari")});ExposedDropdownMenu(de,{de=false}){days.forEachIndexed{i,d->DropdownMenuItem(text={Text(d)},onClick={day=i;de=false})}}};OutlinedTextField(start,{start=it},label={Text("Mulai HH:MM")});OutlinedTextField(end,{end=it},label={Text("Selesai HH:MM")})}},confirmButton={TextButton(onClick={if(title.isNotBlank()&&valid(start)&&valid(end)&&end>start)save(title,cat,day,start,end)}){Text("Simpan",color=Green)}},dismissButton={TextButton(onClick=close){Text("Batal")}})}
@Composable fun WorkoutDialog(close:()->Unit,save:(String,Int,Int,String)->Unit){var title by remember{mutableStateOf("")};var day by remember{mutableIntStateOf(0)};var mins by remember{mutableStateOf("30")};var detail by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,containerColor=Panel,title={Text("Tambah latihan")},text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(title,{title=it},label={Text("Nama latihan")});var ex by remember{mutableStateOf(false)};ExposedDropdownMenuBox(expanded=ex,onExpandedChange={ex=it}){OutlinedTextField(days[day],{},Modifier.menuAnchor().fillMaxWidth(),readOnly=true,label={Text("Hari")});ExposedDropdownMenu(ex,{ex=false}){days.forEachIndexed{i,d->DropdownMenuItem(text={Text(d)},onClick={day=i;ex=false})}}};OutlinedTextField(mins,{mins=it},label={Text("Durasi menit")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number));OutlinedTextField(detail,{detail=it},label={Text("Detail / target")})}},confirmButton={TextButton(onClick={val n=mins.toIntOrNull()?:0;if(title.isNotBlank()&&n>0)save(title,day,n,detail)}){Text("Simpan",color=Green)}},dismissButton={TextButton(onClick=close){Text("Batal")}})}
@Composable fun HabitDialog(close:()->Unit,save:(String)->Unit){var title by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,containerColor=Panel,title={Text("Tambah habit")},text={OutlinedTextField(title,{title=it},label={Text("Nama kebiasaan")})},confirmButton={TextButton(onClick={if(title.isNotBlank())save(title)}){Text("Simpan",color=Green)}},dismissButton={TextButton(onClick=close){Text("Batal")}})}
fun duration(s:String,e:String):Double=try{val a=s.split(":");val b=e.split(":");((b[0].toInt()*60+b[1].toInt())-(a[0].toInt()*60+a[1].toInt()))/60.0}catch(_:Exception){0.0}
fun valid(s:String)=Regex("^([01][0-9]|2[0-3]):[0-5][0-9]$").matches(s)
'''
cat > /mnt/data/GamalWeeklyPlannerAndroid/README.md <<'EOF'
# Gamal Weekly Planner — Android native

Proyek Android Kotlin + Jetpack Compose dengan SQLite lokal (offline-first).

## Fitur versi 1.0
- Dashboard ringkasan 168 jam
- Jadwal per hari: tambah aktivitas, kategori, jam mulai/selesai, tandai selesai, hapus
- Workout tracker: tambah latihan, durasi, hari, tandai selesai
- Habit tracker: habit harian dan checklist per tanggal
- Analisis alokasi jam per kategori
- Data tersimpan di SQLite pada perangkat; tidak memerlukan akun/internet

## Build menjadi APK
1. Ekstrak ZIP proyek.
2. Buka Android Studio (disarankan Ladybug atau lebih baru) → Open → pilih folder `GamalWeeklyPlannerAndroid`.
3. Pastikan JDK 17 dan Android SDK Platform 35 terpasang.
4. Tunggu Gradle Sync; Android Studio akan mengambil dependensi yang diperlukan.
5. Pilih Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK debug ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Ini source project yang dapat dibangun menjadi APK; APK belum dikompilasi di lingkungan ini.
- Penyimpanan offline memakai SQLite. Menghapus data aplikasi/uninstall dapat menghapus data lokal.
- Aktivitas yang melewati tengah malam belum didukung; buat dua entri terpisah.
- Versi awal belum memiliki alarm/notifikasi, cloud sync, backup/restore, atau edit aktivitas setelah dibuat.
