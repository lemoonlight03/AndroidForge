# Gamal Weekly Planner — Android

Aplikasi Android Kotlin + Jetpack Compose dengan penyimpanan SQLite lokal (offline).

Fitur:
- Ringkasan alokasi 168 jam
- Jadwal aktivitas per hari
- Workout tracker
- Habit tracker
- Analisis alokasi waktu per kategori

Build:
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- JDK 17
- Android SDK 35

Build APK melalui Android Studio atau AndroidForge dengan target Android APK dan variant debug.


Build note: this source archive includes a correction for an extra closing brace reported by Kotlin compilation. The project still needs to be built in AndroidForge to verify the complete APK.
